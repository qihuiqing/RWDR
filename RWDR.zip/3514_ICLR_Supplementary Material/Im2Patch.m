function  [Y]  =  Im2Patch(Img,patch_size)
% simplified version
TotalPatNum = (size(Img,1)-patch_size+1)*(size(Img,2)-patch_size+1);               
Y           =   zeros(patch_size.^2, TotalPatNum, 'double');                  
k           =   0;

for i  = 1:patch_size
    for j  = 1:patch_size
        k           =  k+1;
        patch       =  Img(i:end-patch_size+i,j:end-patch_size+j,:);           
        Y(k,:)      =  patch(:)';        
    end
end
