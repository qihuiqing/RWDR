clear all;
close all;

%% load images
I = imread('../imgs/3.png');
% figure(1)
% subplot(121)
% imshow(I)
% title('Original Image')

%% parameters
lambda = 0.0008;      
sharpness = 0.0005; 
varpes = 0.0008;    
maxIter = 4;        
sigma = 2.5;          
    
Wmax = 5;          % window size 
sigma_r = 5;       % Range kernel  
gamma = 0.65;       % Decay parameter 


S = tight_framefilter(I, lambda, sigma, sharpness, varpes, Wmax, sigma_r, gamma, maxIter);

figure, imshow(S,[])
title("Smoothed Image")


