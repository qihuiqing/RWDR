function L = imfilter_gauss(grad,Size)
    mult_grad = mean(grad,3);
    [m, ~] = size(mult_grad);
    L = zeros([Size(1) Size(2) m]);
    for i=1:m
        x = reshape(mult_grad(i,:), Size);
        L(:,:,i) = imgaussfilt(x, 3, 'FilterSize', 11, 'Padding', 'symmetric');
    end
end